package com.projectApplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivity extends AppCompatActivity {

    private Button mStyleButton;
    private Button mNextPageButton;
    private Button mPlaySoundButton;
    private ImageView mImg1;
    int images[] = {R.drawable.image1, R.drawable.image2};
    int i = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        // Executing creator of mother class
        super.onCreate(savedInstanceState);

        // Loading the layout from xml file
        setContentView(R.layout.activity_main);

        mStyleButton = findViewById(R.id.mybutton1);
        mPlaySoundButton = findViewById(R.id.mybutton2);
        mNextPageButton = findViewById(R.id.mybutton3);
        mImg1 = findViewById(R.id.imageView1);
        final MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.click_sound);
        mediaPlayer.start();

        mStyleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // The user just clicked

                mStyleButton.setBackgroundColor(Color.RED);
                mImg1.setImageResource(images[i]);
                i++;
                if (i == images.length)
                    i = 0;
            }
        });

        mPlaySoundButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.start();
            }
        });

        // Testing messages in Logcat
        /*Log.e("DEVE304", "Testing error message.");
        Log.w("DEVE304", "Testing error message.");
        Log.i("DEVE304", "Testing error message.");
        Log.d("DEVE304", "Testing error message.");
        Log.v("DEVE304", "Testing error message.");

        Log.v("DEVE304", "onCreate()"); */
    }

    public void changePage(View view) {
        Intent OtherActivityIntent = new Intent(MainActivity.this, OtherActivity.class);
        startActivity(OtherActivityIntent);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.v("DEVE304", "onStart()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.v("DEVE304", "onStop()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.v("DEVE304", "onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v("DEVE304", "onPause()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.v("DEVE304", "onDestroy()");
    }

    /*public void buttonClick1(View view) {

        /*int iVariable;
        iVariable = 4;
        iVariable --;
        iVariable --;
        iVariable --;
        iVariable --;

        // This will generate an exception
        Log.e("DEVE304", String.valueOf(12/iVariable));*/
        //final Button button = (Button) findViewById(R.id.mybutton1);
        //final ImageView img = (ImageView) findViewById(R.id.imageView1);
        //img.setImageResource(R.drawable.image2);
        //button.setBackgroundColor(Color.RED);


        //Button thisButton1 = (Button) view;

        //thisButton1.setBackgroundColor(Color.RED);

    //}
}